import { Text, SafeAreaView, StyleSheet, View, Image, TouchableOpacity } from 'react-native';
import { useFonts } from 'expo-font';
import { LinearGradient } from 'expo-linear-gradient';
import Constants from 'expo-constants';

export default function Page1({ navigation }) {
  let [fontLoaded] = useFonts({
    'EncodeSans_Condensed-Regular': require('../assets/fonts/EncodeSans_Condensed-Regular.ttf'),
  });

  return (
    <TouchableOpacity
      style={styles.container}
      onPress={() => navigation.navigate('Home')}>
      <LinearGradient
        colors={['#728dec', '#f09595']}
        start={{ x: 1, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.linearGradient}>
        <SafeAreaView style={styles.container}>
          <View style={styles.spacing} />
          <Image
            source={require('../assets/appicon.jpg')}
            style={styles.image}
          />
          <Text style={styles.text}>แตะหน้าจอเพื่อไปต่อ...</Text>
        </SafeAreaView>
      </LinearGradient>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight 
  },
  spacing: {
    paddingTop: 50,
    alignSelf: 'center',
  },
  text: {
    paddingHorizontal: 50,
    paddingVertical: 20,
    borderWidth: 0,
    borderRadius: 0,
    alignItems: 'center',
    fontFamily: 'EncodeSans_Condensed-Regular',
    fontSize: 20,
  },
  image: {
    width: 250,
    height: 250,
    alignSelf: 'center',
  },
  linearGradient: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
