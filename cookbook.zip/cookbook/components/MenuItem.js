import { Text, StyleSheet, View, Image, TouchableOpacity } from 'react-native';
import { useFonts } from 'expo-font';

const MenuItem = ({ name, imageSource, onPress }) => {

  let [fontLoaded] = useFonts({
    'Inter-Bold': require('../assets/fonts/Inter-Bold.ttf')
  });

  return (
    <View style={styles.menuItemContent}>
      <Text style={styles.menuName}>{name}</Text>
      <Image source={imageSource} style={styles.menuImage} />
      <TouchableOpacity onPress={onPress} style={styles.menuButton}>
        <Text style={styles.menuButtonText}>{'>'}</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  menuItemContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 20,
  },
  menuImage: {
    width: 75,
    height: 75,
    borderRadius: 100,
    marginRight: 10,
    position: 'absolute',
    left: 40,
  },
  menuName: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    textAlign: 'center',
    backgroundColor: '#D9D9D9',
    width: 220,
    paddingVertical: 30,
    borderRadius: 25,
    overflow: 'hidden',
  },
  menuButton: {
    backgroundColor: '#66C8E7',
    width: 50,
    height: 50,
    borderRadius: 45,
    position: 'absolute',
    right: 60,
    justifyContent: 'center',
    alignItems: 'center',
  },
  menuButtonText: {
    fontWeight: 'bold',
    fontSize: 24,
  },
});

export default MenuItem;
