import { useState } from 'react';
import { View, Text, Image, TouchableOpacity, SafeAreaView, ScrollView, StyleSheet } from 'react-native';
import { useFonts } from 'expo-font';
import Constants from 'expo-constants';

const MenuDetail = ({ route, navigation }) => {

  let [fontLoaded] = useFonts({
    'Inter-Bold': require('../assets/fonts/Inter-Bold.ttf'),
    'Inter-Medium': require('../assets/fonts/Inter-Medium.ttf'),
    'Inter-Regular': require('../assets/fonts/Inter-Regular.ttf'),
    'Inter-SemiBold': require('../assets/fonts/Inter-SemiBold.ttf')
  });

  const { image, name, ingredient, process } = route.params;
  
  const [textSize, setTextSize] = useState(16);

  const increaseTextSize = () => {
    setTextSize(textSize + 1);
  };

  const decreaseTextSize = () => {
    setTextSize(textSize - 1);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#C3D7EB', paddingTop: Constants.statusBarHeight }}>
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <Image
          source={image}
          style={styles.image}
        />
        <TouchableOpacity style={styles.overlayButton} onPress={() => navigation.navigate('Home')}>
          <Text style={styles.textbtn}> {'<'} </Text>
        </TouchableOpacity>
        <View style={styles.container}>
          <View style={{ backgroundColor: '#FFF' }}>
            <Text style={styles.menu}>
              {name}
            </Text>
          </View>
          <View>
            <Text style={[styles.topic, { fontSize: textSize }]}>
              วัตถุดิบ
            </Text>
          </View>
          <View style={{ backgroundColor: '#FFF' }}>
            <Text style={[styles.text, { fontSize: textSize }]}>
              {ingredient}
            </Text>
          </View>
          <View>
            <Text style={[styles.topic, { fontSize: textSize }]}>
              วิธีทำ
            </Text>
          </View>
          <View style={{ backgroundColor: '#FFF' }}>
            <Text style={[styles.text, { fontSize: textSize }]}>
              {process}
            </Text>
          </View>
          <Text style={{ fontSize: textSize, padding: 15 }}>
              {`
              `}
          </Text>
        </View>
      </ScrollView>
      <View style={styles.footer}>
        <TouchableOpacity style={styles.bottombtn} onPress={decreaseTextSize}>
          <Text style={styles.textbtn}>A-</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.bottombtn} onPress={increaseTextSize}>
          <Text style={styles.textbtn}>A+</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
  },
  image: {
    width: '100%',
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
    resizeMode: 'cover',
  },
  overlayButton: {
    margin: 10,
    position: 'absolute',
    backgroundColor: 'rgba(255, 255, 255, 0.8)' ,
    borderRadius: 20,
    width: 40,
    height: 40,
    justifyContent: 'center',
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    backgroundColor: '#D9D9D9',
  },
  textbtn: {
    textAlign: 'center',
    fontSize: 18,
    fontWeight: 'bold' 
  },
  menu: {
    fontSize: 20,
    textAlign: 'center',
    fontFamily: 'Inter-Bold',
    padding: 15,
  },
  bottombtn: {
    backgroundColor: '#D9D9D9',
    paddingVertical: 10,
    paddingHorizontal: 87.3,
    borderWidth: 1
  },
  text: {
    paddingVertical: 10,
    paddingHorizontal: 15,
    fontFamily: 'Inter-Regular'
  },
  topic: {
    fontFamily: 'Inter-SemiBold',
    padding: 15 
  }
});

export default MenuDetail;